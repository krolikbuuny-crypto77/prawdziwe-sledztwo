/* Pakiet 6.17: lokalna rozgrywka jest dostępna offline, zaś serwer otrzymuje
 * jawny dziennik zdarzeń do niezależnej walidacji. Nigdy nie wysyłamy lokalnego
 * obiektu STATE jako automatycznie zatwierdzonej prawdy. */
(()=>{
 'use strict';
 const K='ps617-pending-actions';
 let queue=[];let rev=null;let busy=false;let restoring=false;let pendingRestore=null;let disabled=false;let timer=0;let retryDelay=1200;let rejectedCount=0;
 let approvedEvidence=new Set();let verifiedVerdict=null;let verifiedIndictment=null;let awaitingResume=!!document.getElementById('psResumeOffer');let resetPending=false;
 try{resetPending=localStorage.getItem('ps617-reset-pending')==='1';}catch{}
 try{queue=JSON.parse(localStorage.getItem(K)||'[]');if(!Array.isArray(queue))queue=[];}catch{queue=[];}
 queue=queue.filter(x=>x&&typeof x.id==='string'&&x.action&&typeof x.action==='object').slice(-100);
 const save=()=>{try{localStorage.setItem(K,JSON.stringify(queue.slice(-100)));}catch{}};
 const state=document.createElement('span');state.id='ps-server-state-status';
 state.setAttribute('aria-live','polite');
 state.style.cssText='font-size:11px;opacity:.7;padding:3px 6px;display:inline-block';
 state.textContent='Zapis lokalny; synchronizacja po połączeniu';
 (document.getElementById('saveBtn')?.parentElement||document.body).appendChild(state);
 const status=text=>{state.textContent=text;};
 function renderServerVerdict(){
  const panel=document.querySelector?.('#simHearingDetail .sim-trial-result');if(!panel)return;
  let node=panel.querySelector('.ps618-confirmation');
  if(!node){node=document.createElement('p');node.className='ps618-confirmation small muted';panel.appendChild(node);}
  node.textContent=verifiedVerdict?.serverApproved?
   'Wynik zatwierdzony na serwerze (rozstrzygający): '+String(verifiedVerdict.label||verifiedVerdict.kind||'sprawa oceniona')+'. Lokalna symulacja ma wyłącznie charakter pomocniczy.':
   'To tylko symulacja lokalna. Wskazanie osoby i końcowy werdykt wymagają zatwierdzenia na serwerze.';
 }

 const key=()=>String(Date.now())+'-'+Math.random().toString(16).slice(2);
 function enqueue(action){
  queue.push({id:key(),action});queue=queue.slice(-100);save();schedule();
 }
 function schedule(delay=650){clearTimeout(timer);timer=setTimeout(sync,delay);}
 async function sync(force=false){
  if(window.PS_COOP?.connecting)return;
  if((restoring&&!force)||awaitingResume||busy||disabled||!navigator.onLine||!/^https?:$/.test(location.protocol))return;
  busy=true;
  try{
   if(resetPending){
    const cleared=await fetch('/api/game-session-reset',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-PS-Client':'game'},body:'{}'});
    if(!cleared.ok)throw Error('session-reset-unavailable');
    resetPending=false;try{localStorage.removeItem('ps617-reset-pending');}catch{}
    rev=null;
   }
   let r=await fetch('/api/game-state',{credentials:'same-origin',cache:'no-store'});
   if(r.status===404||r.status===503){status('Postęp lokalny — serwer nie jest skonfigurowany');disabled=r.status===404;return;}
   if(!r.ok)throw Error('state-read');
   let data=await r.json();if(!data.ok)throw Error('state-error');rev=data.revision;approvedEvidence=new Set(data.state?.approvedEvidence||[]);verifiedVerdict=data.state?.verdict||null;verifiedIndictment=data.state?.indictment||null;renderServerVerdict();
   if(!queue.length){status(rejectedCount?'Część wcześniejszych działań pozostała lokalna (wymaga weryfikacji)':'Postęp serwerowy aktywny · zapis lokalny dostępny');retryDelay=1200;return;}
   const batch=[];let bytes=90;
   for(const item of queue.slice(0,20)){
    const size=encodeURIComponent(JSON.stringify(item)).replace(/%[0-9A-F]{2}/g,"x").length+2;
    if(batch.length&&bytes+size>56000)break;
    batch.push(item);bytes+=size;
   }
   r=await fetch('/api/game-state',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-PS-Client':'game'},
    body:JSON.stringify({revision:rev,actions:batch})});
   if(r.status===409){status('Synchronizacja ponawiana…');retryDelay=1500;return;}
   if(!r.ok)throw Error('state-write');
   data=await r.json();if(!data.ok)throw Error('state-error');rev=data.revision;approvedEvidence=new Set(data.state?.approvedEvidence||[]);verifiedVerdict=data.state?.verdict||null;verifiedIndictment=data.state?.indictment||null;renderServerVerdict();
   const processed=new Set(batch.map(x=>x.id));
   const retryable=new Set(['puzzle_evidence_prerequisite_missing','stage_out_of_order','indictment_not_approved','timeline_anchors_missing']);
   const retryItems=batch.filter((x,i)=>!data.decisions[i]?.ok&&retryable.has(data.decisions[i]?.reason)&&Number(x.retries||0)<100).map(x=>({...x,retries:Number(x.retries||0)+1}));
   queue=[...queue.filter(x=>!processed.has(x.id)),...retryItems].slice(-100);save();
   const rejected=data.decisions.filter((x,i)=>!x.ok&&!retryItems.some(retry=>retry.id===batch[i]?.id)).length;rejectedCount+=rejected;retryDelay=retryItems.length?Math.min(60000,retryDelay*2):1200;
   status(rejected?'Postęp lokalny — część czynności wymaga dalszej weryfikacji':
    queue.length?'Synchronizowanie postępu…':'Zatwierdzony postęp zapisany na serwerze');
  }catch{status('Pracujesz lokalnie — synchronizacja zostanie ponowiona');retryDelay=Math.min(60000,retryDelay*2);}
  finally{busy=false;if((queue.length||resetPending)&&!disabled&&navigator.onLine)schedule(retryDelay);}
 }
 PS_EVENTS.on('evidenceCollected','ps617-server-proposal',e=>{
  if(!e.id||!['area-search','scene-inspection'].includes(e.origin))return;
  const action={type:'collect_evidence',docId:e.id,origin:e.origin};
  if(e.origin==='area-search')action.area=STATE.area;
  else{
   const item=STATE.scene12?.selected,step=STATE.scene12?.steps?.[item];
   action.spotId=item;action.room=STATE.scene12?.room;action.method=step?.method;action.answer=step?.answer;
  }
  enqueue(action);
 });
 // Wersja 6.18: tylko odpowiedzi gracza trafiają na serwer jako PROPOZYCJE.
 // Sam import lokalnego zapisu nie jest dowodem wykonania czynności.
 // Resume choice is explicit. A click outside the prompt must not reset the server session.

 window.addEventListener('online',()=>{disabled=false;if(pendingRestore&&!restoring)restoreTranscript(pendingRestore.saved,{fresh:pendingRestore.fresh});else schedule();});
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')schedule();});
 if(!awaitingResume&&!resetPending){
  // Gra bez wybranego zapisu zaczyna NOWĄ sesję również w Supabase.
  resetPending=true;try{localStorage.setItem('ps617-reset-pending','1');}catch{}
  queue=[];save();
 }
 setTimeout(sync,650);
 document.addEventListener('click',e=>{
  const target=e.target.closest?.('[data-sim-continue],[data-ps54-trial]');if(!target)return;
  setTimeout(()=>{
   if(STATE.sim?.trial)enqueue({type:'request_verdict'});
   renderServerVerdict();
  },0);
 });
 // Zapytania AI o NOWO zdobyty dowód czekają krótko na serwerowe
 // zatwierdzenie. Nie twórz pozornego uprawnienia na podstawie STATE.found.
 async function ensureEvidence(id,timeoutMs=3000){
  if(typeof id!=='string'||!id||awaitingResume||resetPending||!navigator.onLine||disabled)return false;
  if(approvedEvidence.has(id))return true;
  const deadline=Date.now()+Math.max(250,Math.min(4000,timeoutMs));
  // W jednym cyklu przesyłamy do Supabase wszystkie oczekujące czynności
  // z ustaloną wcześniej kolejnością, a potem sprawdzamy approvedEvidence.
  while(Date.now()<deadline){
   if(!busy)await sync();
   if(approvedEvidence.has(id))return true;
   if(!queue.some(item=>item.action?.type==='collect_evidence'&&item.action.docId===id))return false;
   await new Promise(resolve=>setTimeout(resolve,120));
  }
  return approvedEvidence.has(id);
 }
 // A local hypothesis is not a certified identification. Only a verdict
 // matching the current, server-stored indictment may state actor correctness.
 function actorStatusFor(person,local){
  if(!verifiedVerdict?.serverApproved||!verifiedIndictment||!local||!person)return 'pending';
  if(verifiedIndictment.culprit!==person||verifiedVerdict.assessedPerson!==person||
   verifiedIndictment.method!==local.method||verifiedIndictment.alibi!==local.alibi||
   verifiedIndictment.keystone!==local.keystone||
   verifiedIndictment.qualification!==(local.qualification||'intentional'))return 'pending';
  // Do not reuse an old approval after changing source links or explanations.
  const normalizeLinks=items=>JSON.stringify((Array.isArray(items)?items:[]).map(x=>[x.role,x.id]).sort((a,b)=>a.join('|').localeCompare(b.join('|'))));
  if(normalizeLinks(verifiedIndictment.links)!==normalizeLinks(local.links))return 'pending';
  if(['person','method','proof','alibi'].some(k=>String(verifiedIndictment.reasons?.[k]||'')!==String(local.reasons?.[k]||'')))return 'pending';
  return verifiedVerdict.review?.correctPerson===true?'confirmed':'rejected';
 }

 // RC34: an imported save contains *quotes*, not server-certified case facts.
 // Only server HMAC receipts elevate a quote to a server-authenticated utterance.
 const witnessIds=['MAREK','TOMASZ','JANUSZ','ELZBIETA','KAMIL','MAGDALENA'];
 const safeQuote=s=>typeof s==='string'&&s.length>=2&&!/[<>\u0000-\u0008\u000e-\u001f]/.test(s);
 function extractDialogue(saved){
  const groups=[];
  for(const id of witnessIds){
   const rows=saved?.dialogues?.[id];if(!Array.isArray(rows))continue;
   const pairs=[];
   for(let i=1;i<rows.length;i++){
    const q=rows[i-1],a=rows[i];
    if(q?.role!=='player'||a?.role!=='npc'||!safeQuote(q.text)||!safeQuote(a.text))continue;
    const attached=q.text.match(/\n\[Okazano: ([A-Za-z0-9_-]{2,65})\]$/);
    const question=(attached?q.text.slice(0,-attached[0].length):q.text).replace(/[\u0000-\u001f]/g,' ').trim().slice(0,1600);
    const response=a.text.trim();
    if(!safeQuote(question)||question.length>1600||!safeQuote(response)||response.length>1450)continue;
    const ai=a.ai||{};
    pairs.push({question,text:response,provider:ai.provider||'unknown',model:ai.model||null,
     turnId:ai.turnId||null,turnProof:ai.turnProof||null,evidenceId:attached?.[1]||null});
   }
   // The server retains up to 40 question-and-answer pairs per witness.
   if(pairs.length)groups.push({witnessId:id,turns:pairs.slice(-40)});
  }
  return groups;
 }
 function restoreLabel(restored,verified,skipped,unverified){
  status('Pamięć rozmów: '+restored+' przywrócono ('+verified+' podpisanych, '+unverified+' niezweryfikowanych), '+skipped+' duplikatów');
 }
 async function restoreTranscript(saved,{fresh=false}={}){
  if(!saved||typeof saved!=='object')return {ok:false,reason:'invalid_save'};
  pendingRestore={saved,fresh};
  if(restoring)return {ok:false,reason:'restore_busy'};
  if(!navigator.onLine||!/^https?:$/.test(location.protocol)){
   status('Historia lokalna · pamięć AI czeka na połączenie');
   return {ok:false,reason:'offline'};
  }
  restoring=true;
  let resetCompleted=!fresh;
  let restored=0,verified=0,unverified=0,skipped=0;
  try{
   awaitingResume=false;disabled=false;
   // Avoid racing the queued state writer during the import/reset.
   for(let tries=0;busy&&tries<100;tries++)await new Promise(r=>setTimeout(r,100));
   if(busy)throw Error('server_sync_busy');
   if(fresh){
    // If this is the SAME server session, retain the originally verified
    // testimony and progress. A different case must not inherit its evidence.
    const groups=extractDialogue(saved);
    let keep=false;
    const current=await fetch('/api/game-state',{credentials:'same-origin',cache:'no-store'});
    if(current.ok){
     const data=await current.json();
     const serverRows=data?.state?.witnesses||{};
     keep=groups.some(group=>group.turns.some(t=>{
      const history=serverRows[group.witnessId]||[];
      return history.some((r,i)=>r?.role==='witness'&&r.text===t.text&&history[i-1]?.role==='player'&&history[i-1]?.text===t.question);
     }));
    }
    if(keep){
     resetPending=false;
     try{localStorage.removeItem('ps617-reset-pending');}catch{}
    }
    if(!keep){
     // A different case must start with new server-owned progress, rather than
     // accidentally inheriting old approvals from the previous cookie session.
     window.PS617_SYNC.resetSession();
     await sync(true);
     if(resetPending)throw Error('server_reset_unavailable');
    }
    resetCompleted=true;
   }else if(resetPending){
    await sync(true);
    if(resetPending)throw Error('server_reset_unavailable');
   }
   const groups=extractDialogue(saved);
   for(const {witnessId,turns} of groups){
    for(let i=0;i<turns.length;i+=8){
     let batch=turns.slice(i,i+8);
     // Keep the JSON body below the server's 36 KB UTF-8 limit.
     while(batch.length>1&&new TextEncoder().encode(JSON.stringify({witnessId,turns:batch})).length>29000)batch=batch.slice(0,-1);
     i+=batch.length-8;
     let done=false;
     for(let attempt=0;attempt<3;attempt++){
      const result=await fetch('/api/interview-restore',{method:'POST',credentials:'same-origin',
       headers:{'Content-Type':'application/json','X-PS-Client':'game'},
       body:JSON.stringify({witnessId,turns:batch})});
      if(result.status===409)continue;
      if(!result.ok)throw Error('history_restore_http_'+result.status);
      const data=await result.json();if(!data.ok)throw Error('history_restore_rejected');
      restored+=Number(data.restored)||0;verified+=Number(data.verified)||0;
      unverified+=Number(data.unverified)||0;skipped+=Number(data.skipped)||0;
      done=true;break;
     }
     if(!done)throw Error('history_restore_conflict');
    }
   }
   pendingRestore=null;restoreLabel(restored,verified,skipped,unverified);
   schedule();return {ok:true,restored,verified,unverified,skipped};
  }catch(err){
   // Keep the save available for an explicit retry or when connection returns.
   status('Historia lokalna · synchronizacja pamięci AI nieukończona');
   pendingRestore={saved,fresh:!resetCompleted};
   return {ok:false,reason:String(err.message||'restore_failed'),restored};
  }finally{restoring=false;}
 }
 window.PS617_SYNC=Object.freeze({
  ensureEvidence,actorStatusFor,restoreTranscript,get restoring(){return restoring;},isEvidenceApproved:id=>approvedEvidence.has(id),
  enqueue,get approvedVerdict(){return verifiedVerdict;},get pending(){return queue.length;},get enabled(){return !disabled;},get rejected(){return rejectedCount;},
  coopJoined(){
   awaitingResume=false;resetPending=false;queue=[];save();rev=null;disabled=false;
   try{localStorage.removeItem('ps617-reset-pending');}catch{}
   document.getElementById('psResumeOffer')?.remove();document.body.classList.remove('ps-resume-pending');
   status('Wspólne śledztwo — stan sprawy na serwerze');schedule();
  },
  resume(){awaitingResume=false;disabled=false;schedule();},
  resetSession(){
   awaitingResume=false;queue=[];save();resetPending=true;rev=null;approvedEvidence.clear();verifiedVerdict=null;verifiedIndictment=null;disabled=false;
   try{localStorage.setItem('ps617-reset-pending','1');}catch{}
   status('Nowa sesja lokalna — reset serwera po połączeniu');schedule();
  },retry:sync
 });
})();
